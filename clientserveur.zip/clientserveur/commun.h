#ifndef COMMON_H
#define COMMON_H

#define PORT 8080
#define BUFFER_SIZE 1024

#endif

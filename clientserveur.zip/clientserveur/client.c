#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "common.h"

int main() {
    int sock;
    struct sockaddr_in serv_addr;
    int compteur;

    // Création du socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Erreur de création du socket");
        exit(EXIT_FAILURE);
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Conversion de l'adresse IP
    if (inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr) <= 0) {
        perror("Adresse invalide ou non supportée");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Connexion au serveur
    if (connect(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Erreur de connexion");
        close(sock);
        exit(EXIT_FAILURE);
    }

    printf("Client connecté au serveur\n");

    while (1) {
        // Recevoir le compteur du serveur
        read(sock, &compteur, sizeof(compteur));
        printf("Client : Compteur reçu = %d\n", compteur);

        // Incrémenter le compteur
        compteur++;
        printf("Client : Compteur incrémenté = %d\n", compteur);

        // Envoyer le compteur au serveur
        send(sock, &compteur, sizeof(compteur), 0);

        // Pause d'une seconde
        sleep(1);
    }

    close(sock);
    return 0;
}
